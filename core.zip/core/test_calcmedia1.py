def calcula_media(n1,n2,n3):
  media = (n1+n2+n3) / 3
  return media
           
def test_calcula_media():  
  assert calcula_media (1,2,3) == 2

    

        
